//
//  ProductHeaderView.m
//  GopherCNYS
//
//  Created by Innotech on 3/12/15.
//  Copyright (c) 2015 cnys. All rights reserved.
//

#import "ProductHeaderView.h"

@implementation ProductHeaderView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
